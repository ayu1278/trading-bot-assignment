
from bot.logging_config import logger

class OrderManager:
    def __init__(self, client):
        self.client = client

    def place_order(self, symbol, side, order_type, quantity, price=None):
        try:
            logger.info(
                f"Creating order: {symbol} {side} {order_type} qty={quantity} price={price}"
            )

            params = {
                "symbol": symbol.upper(),
                "side": side,
                "type": order_type,
                "quantity": quantity
            }

            if order_type == "LIMIT":
                params["price"] = price
                params["timeInForce"] = "GTC"

            response = self.client.futures_create_order(**params)

            logger.info(f"Order Response: {response}")

            return {
                "success": True,
                "orderId": response.get("orderId"),
                "status": response.get("status"),
                "executedQty": response.get("executedQty"),
                "avgPrice": response.get("avgPrice", "N/A"),
                "full_response": response
            }

        except Exception as e:
            logger.error(f"Order Failed: {str(e)}")
            return {
                "success": False,
                "error": str(e)
            }
