
import argparse
from bot.client import BinanceFuturesClient
from bot.orders import OrderManager
from bot.validators import (
    validate_side,
    validate_order_type,
    validate_quantity,
    validate_price
)

def main():
    parser = argparse.ArgumentParser(description="Binance Futures Testnet Trading Bot")

    parser.add_argument("--symbol", required=True, help="Trading pair (e.g. BTCUSDT)")
    parser.add_argument("--side", required=True, help="BUY or SELL")
    parser.add_argument("--type", required=True, help="MARKET or LIMIT")
    parser.add_argument("--quantity", required=True, type=float, help="Order quantity")
    parser.add_argument("--price", type=float, help="Price for LIMIT order")

    args = parser.parse_args()

    try:
        side = validate_side(args.side)
        order_type = validate_order_type(args.type)
        quantity = validate_quantity(args.quantity)
        price = validate_price(args.price, order_type)

        print("\n========== ORDER REQUEST ==========")
        print(f"Symbol      : {args.symbol}")
        print(f"Side        : {side}")
        print(f"Order Type  : {order_type}")
        print(f"Quantity    : {quantity}")

        if order_type == "LIMIT":
            print(f"Price       : {price}")

        client = BinanceFuturesClient().get_client()
        manager = OrderManager(client)

        result = manager.place_order(
            symbol=args.symbol,
            side=side,
            order_type=order_type,
            quantity=quantity,
            price=price
        )

        print("\n========== RESPONSE ==========")

        if result["success"]:
            print("Order placed successfully!")
            print(f"Order ID     : {result['orderId']}")
            print(f"Status       : {result['status']}")
            print(f"Executed Qty : {result['executedQty']}")
            print(f"Average Price: {result['avgPrice']}")
        else:
            print("Order failed!")
            print(f"Error: {result['error']}")

    except Exception as e:
        print(f"Validation/Error: {e}")

if __name__ == "__main__":
    main()
